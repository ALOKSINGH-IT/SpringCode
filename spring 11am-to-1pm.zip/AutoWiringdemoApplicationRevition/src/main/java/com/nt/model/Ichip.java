package com.nt.model;

public interface Ichip {
	
	public void commChip();

}
