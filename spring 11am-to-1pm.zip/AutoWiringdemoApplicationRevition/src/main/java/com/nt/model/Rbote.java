package com.nt.model;

public class Rbote {
	

}
