package com.nt.model;

public class EmployeeBean {
	private int eid;
	private String ename;
	 private DepartmentBean department;
	 
	public void setEid(int eid) {
		this.eid = eid;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public void setDepartment(DepartmentBean department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "EmployeeBean [eid=" + eid + ", ename=" + ename + ", department=" + department + "]";
	}
	 

}
