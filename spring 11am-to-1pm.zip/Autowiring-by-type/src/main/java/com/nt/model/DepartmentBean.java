package com.nt.model;

public class DepartmentBean {
	private int did;
	private String dname;
	public DepartmentBean() {
		super();
	}
	public DepartmentBean(int did, String dname) {
		super();
		this.did = did;
		this.dname = dname;
	}
	@Override
	public String toString() {
		return "DepartmentBean [did=" + did + ", dname=" + dname + "]";
	}
	

}
