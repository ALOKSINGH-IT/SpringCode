package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.EmployeeBean;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/nt/cfg/Beans.xml");
		 EmployeeBean eb = context.getBean("e1", EmployeeBean.class);
	System.out.println(eb);
	}

}
