
public class SeconLarjest {
	public static void main(String[] args) {
		
		 int Input[]= {66,33,22,3,55,34,65};
		 int maxlargest=0,SecondLargest=0;
		 
		 for(int i=0; i<Input.length;i++ ) {
			 
			 if(Input[i]>maxlargest)
			 {
				 SecondLargest=maxlargest;
				 maxlargest=Input[i];
			 }else if(Input[i]>SecondLargest)
			 {
				 SecondLargest=Input[i];
				 
			 }
		 }
		 System.out.println(SecondLargest);
	}

}
