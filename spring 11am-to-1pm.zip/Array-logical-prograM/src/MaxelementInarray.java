
public class MaxelementInarray {

	public static void main(String[] args) {

		int input[]= {10,30,50,60,3,2};
		
		int max=input[0];
		for(int i=1;i<input.length;i++)
		{
			if(max>input[i])
			{
				max=input[i];
			}
		}
		System.out.println(max);
	}

}
