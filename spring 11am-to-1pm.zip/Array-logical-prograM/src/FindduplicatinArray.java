import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class FindduplicatinArray {

	public static void main(String[] args) {
		
		
		int a[]= {10,7,5,4,4,6,6,10};
		Set s=new HashSet<Integer>();
		Set s1=new HashSet<Integer>();
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j]&&i!=j)
				{
					s.add(a[i]);
					
				}else
				{
					s1.add(a[i]);
				}
			}
		}
		
		System.out.println(s);
		
		System.out.println("after removing elemnts"+s1);
	}
}
