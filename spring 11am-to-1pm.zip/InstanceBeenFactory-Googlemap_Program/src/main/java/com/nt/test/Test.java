package com.nt.test;

import java.util.Calendar;
import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.st.model.CalenderUtil;
import com.st.model.DrowMap;

import sun.util.calendar.CalendarUtils;

public class Test {
	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("com/nt/cfg/beans.xml","com/nt/cfg/Bean2.xml");
		 DrowMap dm =ctx.getBean("tg", DrowMap.class);
		 dm.getDirection("abc", "bcd");
	
		 CalenderUtil cu =ctx.getBean("cutil", CalenderUtil.class);
		cu.getDate(new Date(), 10);
		
		
	}

}
