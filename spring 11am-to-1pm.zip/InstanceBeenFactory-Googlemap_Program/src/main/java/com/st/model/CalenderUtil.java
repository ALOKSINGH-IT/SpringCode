package com.st.model;

import java.util.Calendar;
import java.util.Date;

public class CalenderUtil {

	Calendar cal;
	
	public void setCal(Calendar cal) {
		this.cal = cal;
	}

	public void getDate(Date d,int a)
	{
		cal.setTime(d);
	
		cal.add(Calendar.DAY_OF_MONTH, a);
		
		Date finaldate=cal.getTime();
		
		System.out.println(finaldate);
	}
	
}
