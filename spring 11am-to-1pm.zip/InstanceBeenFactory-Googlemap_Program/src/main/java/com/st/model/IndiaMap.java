package com.st.model;

public class IndiaMap implements Imap {

	public String[] getDirection(String source, String Destenace) {

		String ind[]= {"indore","ameerpet","murena","Agra"};
		return ind;
	}

}
