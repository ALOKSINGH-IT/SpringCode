package com.st.model;

public class DrowMap {
	private Imap imap;

	public void setImap(Imap imap) {
		this.imap = imap;
	}
	public void getDirection(String source,String destenation) {
	String ar[]=	imap.getDirection(source, destenation);
		
	for(String rs:ar)
	{
		System.out.println(rs);
	}
	}
	
	

}
