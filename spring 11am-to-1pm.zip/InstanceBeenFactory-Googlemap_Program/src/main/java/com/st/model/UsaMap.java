package com.st.model;

public class UsaMap implements Imap {

	public String[] getDirection(String source, String Destenace) {

	String res[]= {"Wc","Los of angles","white house "};
	return res;
	}

}
