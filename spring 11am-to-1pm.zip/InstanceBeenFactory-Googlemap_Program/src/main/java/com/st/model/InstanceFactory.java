package com.st.model;

public class InstanceFactory {
	
	
	public Object getIndia()
	{
		return new IndiaMap();
	}

	public Object getUsaMap()
	{
		return new UsaMap();
	}
}
