package com.st.model;

public interface Imap {
	public String[] getDirection( String source,String Destenace);
	
 
}
