package com.nt.model;

import lombok.Data;

@Data
public class Company {
	private String cmpAddress;
	private int ccode;
	

}
