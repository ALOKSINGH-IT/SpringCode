package com.nt.model;

import lombok.Data;

@Data
public class Employee {
	private int eno;
	private String empname;
	private String empAddress;
	
	

}
