package singal.com.nt;

public class DateUtil {
	public static DateUtil instance;

	public DateUtil() {
		
	}
	public static DateUtil getinstance() {
		if(instance==null) {
			instance=new DateUtil();
		
		}
		return instance;
		
	}
	

}
