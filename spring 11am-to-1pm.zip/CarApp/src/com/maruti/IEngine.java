package com.maruti;

public interface IEngine {

	public int start();

}
