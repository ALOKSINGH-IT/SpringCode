package com.maruti;

public class PetrolEngine implements IEngine{

	public int start() {
		System.out.println("Petrol Engine Started...");
		return 0;
	}

}
