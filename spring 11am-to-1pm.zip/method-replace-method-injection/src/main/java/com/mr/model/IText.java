package com.mr.model;

public class IText {
	
	public void generateReport()
	{
		System.out.println("Report generates by  Itext ::api");
}
}
