package com.nt.model;

public class MessageProducer {
	private IMessageFormate imessageproducer;

	public void setImessageproducer(IMessageFormate imessageproducer) {
		this.imessageproducer = imessageproducer;
	}
public void WriteMessage(String Message) {
	
	//imessageproducer=new  HtmlMessageProducer();
	 String anyformate =imessageproducer.FormateMessage("wellcome to Spring Class ");
	 
	System.out.println(anyformate);
}
	
	


}
