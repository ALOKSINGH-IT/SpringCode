package com.nt.model;

public interface IMessageFormate {
String	FormateMessage(String Message);

}
