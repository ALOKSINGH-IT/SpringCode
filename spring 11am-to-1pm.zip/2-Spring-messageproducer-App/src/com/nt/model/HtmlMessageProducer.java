package com.nt.model;

public class HtmlMessageProducer implements IMessageFormate {

	@Override
	public String FormateMessage(String Message) {
		// TODO Auto-generated method stub
		return "<HTML><HEAD></HEAD><BODY>"+ Message+ "</BODY></HTML>";
	}
	

}
