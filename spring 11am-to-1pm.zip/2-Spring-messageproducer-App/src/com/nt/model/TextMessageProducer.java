 package com.nt.model;

public class TextMessageProducer implements IMessageFormate {

	@Override
	public String FormateMessage(String Message) {
		// TODO Auto-generated method stub
		return "Hello" + Message +"!";
	}
	

}
