package com.nt.trest;

import javax.annotation.Resource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.nt.model.MessageProducer;

public class Test {
public static void main(String[] args) {
		//Resource resource = new ClassPathResource("com/nt/comm/beans.xml");
		//BeanFactory factory = new XmlBeanFactory(resource);
BeanFactory factory = new XmlBeanFactory (new ClassPathResource("com/nt/comm/beans.xml"));
MessageProducer mp =factory.getBean("Textms", MessageProducer.class);
	mp.WriteMessage("this is Html formate");
	
	
	} 
}
