package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.nt.model.Bike;

public class Test {
	public static void main(String[] args) {
		 // ApplicationContext context = new ClassPathXmlApplicationContext(".xml");
		
		Resource res= new ClassPathResource("com/nt/cfg/beans.xml");
		BeanFactory factory= new XmlBeanFactory(res);
		 Bike ep=factory.getBean("pulsor1", Bike.class);
		/* Bike ep1=factory.getBean("pulsor1", Bike.class);
		*/
		
		System.out.println(ep);
	}

}
