package com.nt.test;

import javax.annotation.Resource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.nt.beans.Car;

public class Test {

	public static void main(String[] args) throws Exception {
		BeanFactory factory= new XmlBeanFactory(new ClassPathResource("com/nt/comm/Bean.xml"));
		Car c = factory.getBean("car", Car.class);
		c.Drive();

	}

}
