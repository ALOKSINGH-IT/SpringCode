package com.nt.beans;

public class DieselEngine implements IEngine {

	@Override
	public int start() {
		System.out.println("DieselEngine started");
		return 0;
	}
	
	

}
