package com.nt.beans;

public class Car {
private IEngine eng;

public void setEng(IEngine eng) {
		this.eng = eng;
	}
public  void Drive() throws Exception {
	 int engineStatus = eng.start();
System.out.println("Car Driving:: "+ engineStatus);
		 }
	 }
