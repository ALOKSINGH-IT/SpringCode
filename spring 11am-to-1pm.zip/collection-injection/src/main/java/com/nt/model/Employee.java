package com.nt.model;

import java.util.List;
import java.util.Set;

import lombok.Data;

@Data
public class Employee {
	private String ename;
	private int eage;
	private List<String> visitedPlaces;
	private Set<String> course;

}
