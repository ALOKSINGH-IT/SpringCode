package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.nt.model.MessageWriter;

public class Test {
	public static void main(String[] args) {
		Resource res= new ClassPathResource("com/nt/comm/beans.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		MessageWriter mes=factory.getBean("mwriter" ,MessageWriter.class);
		 mes.messageWrite("how are you");
		
	}

}
