package com.nt.model;

public class XmlFormate  implements ImessageWriter {

	public String writmessage() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
