package com.nt.model;

public interface ImessageWriter  {
	public String writmessage();

}
