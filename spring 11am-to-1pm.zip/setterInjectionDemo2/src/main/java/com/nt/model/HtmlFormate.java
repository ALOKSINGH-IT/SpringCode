package com.nt.model;

public class HtmlFormate implements ImessageWriter {

	public String writmessage() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
