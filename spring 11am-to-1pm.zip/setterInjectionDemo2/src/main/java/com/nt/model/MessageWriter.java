package com.nt.model;

public class MessageWriter {
	private ImessageWriter imessagewriter ;

	public MessageWriter() {
		System.out.println("super class constructor");
		//super();
	}

	public MessageWriter(ImessageWriter imessagewriter) {
		super();
		this.imessagewriter = imessagewriter;
	}
	public  void messageWrite(String msg) {
		String app = imessagewriter.writmessage();
		
}
	}
