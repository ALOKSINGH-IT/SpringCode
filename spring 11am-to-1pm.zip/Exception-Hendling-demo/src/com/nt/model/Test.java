package com.nt.model;

public class Test {
	/* public static void main(String[] args) {
 int a = 12;
		    int b = 2;
try {
		       int result = a / (a - 2);
		       System.out.println(result);}
catch (Exception e)
{ System.out.println("Error: "+ e.getMessage() );
		       e.printStackTrace();
		    }}}*/
	
	/*public static void main(String[] args)
	{
	try
	{
	System.out.println(10/0);
	}
	catch(ArithmeticException e)
	{
	e.printStackTrace();
	}
	catch(Exception e){
	e.printStackTrace();
	}}
}*/
	public static void main(String[] args)
	{
	try
	{
	System.out.println("try block executed");
	}
	catch(ArithmeticException e)
	{
	System.out.println("catch block executed");
	}
	finally
	{
	System.out.println("finally block executed");
	}
	}
	}
	
	
	
	
	
	
	