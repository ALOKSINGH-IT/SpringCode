
public class CountCharInString {

	public static void main(String[] args) {

		
	}

}
