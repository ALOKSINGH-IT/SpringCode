package com.nt.model;

public interface IMessageWriter {
	public String WriteFormate(String msg);

	//public String WriteFormate(String msg);

}
