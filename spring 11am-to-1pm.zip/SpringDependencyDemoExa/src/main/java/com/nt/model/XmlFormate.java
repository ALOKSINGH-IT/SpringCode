package com.nt.model;

public class XmlFormate  implements IMessageWriter {

	public String WriteFormate(String msg) {
		// TODO Auto-generated method stub
		return "<xml>"+ msg + "</xml>";
	}

	@Override
	public String toString() {
		return "XmlFormate []";
	}
	
	

}
