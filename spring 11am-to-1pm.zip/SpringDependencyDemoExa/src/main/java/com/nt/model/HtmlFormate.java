package com.nt.model;

public class HtmlFormate  implements IMessageWriter{

		// TODO Auto-generated method stub

	

	public String WriteFormate(String msg ) {
		
		
		// TODO Auto-generated method stub
		return "<HTML><HEAD></HEAD><BODY>"+ msg  + "</BODY></HTML>";
	}
	

}
