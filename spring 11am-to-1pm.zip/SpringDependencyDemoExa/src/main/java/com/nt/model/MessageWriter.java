package com.nt.model;

import com.nt.model.IMessageWriter;

public class MessageWriter {
	 private IMessageWriter imessagewriter ;

	public MessageWriter() {
		System.out.println("super class constructor");
		//super();
	}

	public MessageWriter(IMessageWriter imessagewriter) {
		super();
		this.imessagewriter = imessagewriter;
	}
	public  void messageWrite(String msg) {
		String app = imessagewriter. WriteFormate("how are you");
		//return "write any";
		
		
	}
	
	 
	

}
