package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.nt.model.XmlFormate;

public class Test {
	//public static void main(String[] args)
	public static synchronized final strictfp void main(String... args)
	{
		Resource resource = new ClassPathResource("com/nt/beans/beans.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		XmlFormate xft=	factory.getBean("xmfrt",XmlFormate.class);
		System.out.println(xft);
		
	}

}
