package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.NewService;
import com.nt.model.ReportGenrator;
import com.sun.org.apache.bcel.internal.util.ClassPath;

public class Test {
	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("com/nt/cfg/beans.xml");
		NewService rpt	= ctx.getBean("newservice",NewService.class);
		
		
		//System.out.println
		rpt.newgenrep();
	}

}
