package com.nt.model;

public class AsposeReportGenator  implements IReportGenaretor{

	public void reportGenarator() {
		// TODO Auto-generated method stub
		System.out.println("AspoeReports report genarator");
	}

}
