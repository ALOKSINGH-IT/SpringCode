package com.nt.model;

public class ReportGenrator {
	public IReportGenaretor poi;

	
	public void setPoi(IReportGenaretor poi) {

		this.poi = poi;
	
	}
	

	public void genaretreport() {
		
		poi.reportGenarator();
		
		
	}
	
}
