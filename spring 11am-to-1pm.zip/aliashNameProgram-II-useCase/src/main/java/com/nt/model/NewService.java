package com.nt.model;

public class NewService  {
	IReportGenaretor ireportor;

	public void setIreportor(IReportGenaretor ireportor) {
		this.ireportor = ireportor;
	
	
		
	}

	public void newgenrep()
	{
		ireportor.reportGenarator();
		
	}
}
