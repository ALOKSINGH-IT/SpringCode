package com.nt.model;

public class PoiReportGenrator implements IReportGenaretor {

	public void reportGenarator() {
		// TODO Auto-generated method stub
		System.out.println("poi report genarator");
		
	}
	

}
