package com.nt.model;

public interface IReportGenaretor {
	public  void reportGenarator();

}
