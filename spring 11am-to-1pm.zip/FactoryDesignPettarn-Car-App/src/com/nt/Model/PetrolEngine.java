package com.nt.Model;

public class PetrolEngine implements IEngine {
	
         public int start() {
	System.out.println("Petrol Engine Started...");
	return 0;
}
}
