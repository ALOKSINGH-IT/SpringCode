package com.nt.Model;

public interface IEngine {
	public int start();
}

