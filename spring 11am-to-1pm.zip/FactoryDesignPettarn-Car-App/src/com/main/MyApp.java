package com.main;

import com.nt.Model.Car;
import com.nt.Model.EngineFactory;
import com.nt.Model.IEngine;

public class MyApp {
	public static void main(String[] args) throws Exception {

		// Getting Engine
	IEngine eng = EngineFactory.createEngine("Petrol");
         
		// Constructor Injection
		Car c = new Car(eng);

		// calling drive method
		c.drive();
	}

}
