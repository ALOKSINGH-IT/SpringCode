package com.nt.model;

public class Person {
	private int pid;
	private String pname;
	private Address adrress;
	private Address prmntaddress;
	
	public void setPrmntaddress(Address prmntaddress) {
		this.prmntaddress = prmntaddress;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public void setAdrress(Address adrress) {
		this.adrress = adrress;
	}
	@Override
	public String toString() {
		return "Person [pid=" + pid + ", pname=" + pname + ", adrress=" + adrress + ", prmntaddress=" + prmntaddress
				+ "]";
	}
	

}
