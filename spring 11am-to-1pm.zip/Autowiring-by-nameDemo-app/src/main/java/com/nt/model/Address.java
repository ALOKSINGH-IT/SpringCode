package com.nt.model;
public class Address {
	private int aid;
	private String city;
	private String state;
	
	public Address() {
		super();
	}
	public Address(int aid, String city, String state) {
		super();
		this.aid = aid;
		this.city = city;
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [aid=" + aid + ", city=" + city + ", state=" + state + "]";
	}
	
	
}
