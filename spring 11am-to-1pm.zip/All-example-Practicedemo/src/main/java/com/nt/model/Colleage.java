package com.nt.model;

public class Colleage {
	private int cid;
	private String cname;
	
	/*public Colleage() {
		super();}
public Colleage(int cid, String cname) {
		super();
		this.cid = cid;
		this.cname = cname;}*/
	

	@Override
	public String toString() {
		return "Colleage [cid=" + cid + ", cname=" + cname + "]";
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	
	

}
