package com.nt.model;

public class Movie {
	private Integer movieId;
	private String producerName;
	private String directorName;
	private String movieName;   // null injection
	private String hero;
	private String heroine;
	
	public Movie() {
		super();
	}
	public Movie(Integer movieId, String producerName, String directorName, String movieName, String hero,
			String heroine) {
		super();
		this.movieId = movieId;
		this.producerName = producerName;
		this.directorName = directorName;
		this.movieName = movieName;
		this.hero = hero;
		this.heroine = heroine;
	}
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", producerName=" + producerName + ", directorName=" + directorName
				+ ", movieName=" + movieName + ", hero=" + hero + ", heroine=" + heroine + "]";
	}
	

}
