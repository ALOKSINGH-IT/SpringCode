package com.nt.test;

public class Addtion {
	//class Addition 
	 	 int a = 10;
     	 int b = 20;
		void add(){
		System.out.println("Additon:" +(a+b));
		}
		public static void main(String[] args) 
		{
			
		//Addtion obj = new Addtion();  //object
		//obj.add();  // method call
		System.out.println((a+b));
		}
		}



