package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.Company;
import com.nt.model.Employee;
import com.sun.org.apache.bcel.internal.util.ClassPath;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/nt/cfg/beans.xml");
		Company com = context.getBean("c1", Company.class);
		System.out.println(com);
		
		Employee emp =context.getBean("e1", Employee.class);
		System.out.println(emp);
		
	}

}
