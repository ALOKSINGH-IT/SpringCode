package com.nt.model;

public class Company {
	private int cno;
	private String cname;
	public Company(int cno, String cname) {
		super();
		this.cno = cno;
		this.cname = cname;
	}
	@Override
	public String toString() {
		return "Company [cno=" + cno + ", cname=" + cname + "]";
	}

}
