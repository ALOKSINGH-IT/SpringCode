package com.fb.pettrn;

public class ModifiyedStorePizza {
	public Pizza orderPizza(String type) {
		
		Pizza p=null;
		p= PizzaFectory.createpizza("normal");
		
		p.back();
		p.cut();
		p.prepare();
		return p;
	}}


