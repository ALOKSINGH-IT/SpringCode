package com.fb.pettrn;

public class SpicyPijja extends Pizza {
	protected String spicyType;

	public String getSpicyType() {
		return spicyType;
	}

	public void setSpicyType(String spicyType) {
		this.spicyType = spicyType;
	}

	@Override
	public String toString() {
		return "SpicyPijja [spicyType=" + spicyType + "]";
	}
	

}
