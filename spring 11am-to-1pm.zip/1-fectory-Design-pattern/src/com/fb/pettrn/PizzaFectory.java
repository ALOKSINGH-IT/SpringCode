package com.fb.pettrn;

public class PizzaFectory {
	public static Pizza  createpizza(String type) {
		Pizza p=null;
		if(type.equals("normal")) {
			p=new Pizza();
		}
			else if(type.equals("cheese")) {
			p=new CheesPizza();
			}
			else if(type.equals("SpicyPijja")) {
				p=new SpicyPijja();
			}
		return p;
	}

}
