package com.fb.pettrn;

public class Pizza {
	private int productid;
	private float price;
	
	public void prepare() {
		System.out.println("preparing");
	}
	public void back() {
		System.out.println("backing");
	}
	public void cut() {
		System.out.println("cuting");
		
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Pizza [productid=" + productid + ", price=" + price + "]";
	}

	
}
