package com.fb.pettrn;

public class Main {
	public static void main(String[] args) {
		ModifiyedStorePizza msp=null;
		msp=new ModifiyedStorePizza();
		msp.orderPizza("normal");
	
	}

}
