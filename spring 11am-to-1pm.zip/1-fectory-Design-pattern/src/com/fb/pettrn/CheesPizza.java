package com.fb.pettrn;

public class CheesPizza extends Pizza {
	protected String cheesetype;
	

	public String getCheesetype() {
		return cheesetype;
	}

	public void setCheesetype(String cheesetype) {
		this.cheesetype = cheesetype;
	}

	@Override
	public String toString() {
		return "CheesPizza [cheesetype=" + cheesetype + "]";
	}
	

}
