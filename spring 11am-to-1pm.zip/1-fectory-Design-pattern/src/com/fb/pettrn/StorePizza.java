package com.fb.pettrn;

public class StorePizza {
	public Pizza  orderPizza(String type) {
		Pizza p=null;
		if(type.equals("normal")) {
		p=new Pizza();
	}
		else if(type.equals("cheese")) {
		p=new CheesPizza();
		}
		else if(type.equals("SpicyPijja")) {
			p=new SpicyPijja();
		}
		p.prepare();
		p.back();
		p.cut();
		
		return p;
		
	}
}


