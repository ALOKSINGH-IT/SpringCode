package com.nt.model;

public class Tokan {
	//TokanGenareted tokanGenarete

	public Tokan() {
		
		System.out.println("Tokan.Tokan()...");
		
		
	}

	
	
	

}
