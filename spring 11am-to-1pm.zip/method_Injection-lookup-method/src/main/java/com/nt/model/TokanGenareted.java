package com.nt.model;

 public class TokanGenareted {

Tokan tokan;

public void setTokan(Tokan tokan) {
	this.tokan = tokan;
}


public void check()
{
	System.out.println("TokanGenareted.check()");
}

	

	
	

}
