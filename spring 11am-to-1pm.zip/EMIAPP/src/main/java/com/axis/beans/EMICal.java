package com.axis.beans;

public class EMICal {

}
