package com.axis.beans;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

import com.sun.org.apache.xml.internal.dtm.Axis;

public class CacheLoader {

	private Cache cache;
	
	public CacheLoader(Cache cache)
	{
		this.cache=cache;
		
		loadWrite();
	}
	
	
	public void loadWrite() {
		try {
			
			// create the fileinputstream object 
			//this is used to check whether file is there  or not
			FileInputStream file = new FileInputStream("axis-rt.properties");
// create the properties class object and load the file in to properties class object
			Properties ps = new Properties();

			try {
				ps.load(file);
				// keySet() is used to get the all the keys from properties file  and 
				 
				Set<Object>  keys = 	ps.keySet();
				
				for(Object key:keys)
				{
					
					      
					      String value=(String) ps.get(key);
					        
					      cache.put(key.toString(), Double.parseDouble(value));
					      
					      
					      
					      
					      
				}
				for(Object gg:keys)
				{
					String vl=(String) gg;
					System.out.println(cache.get(vl));
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
