package com.axis.beans;

import java.util.HashMap;
import java.util.Map;

public class Cache {
 int id;
	private Map<String, Double> cachemap= new HashMap<String,Double>();
	public void put(String key, Double value) {
		
		cachemap.put(key,value);
		
	}
	public void setId(int id) {
		this.id = id;
	}
	public double get(String key)
	{
		return cachemap.get(key);
	}

	public String toString()
	{
		return "id="+id;
	}
	
}
