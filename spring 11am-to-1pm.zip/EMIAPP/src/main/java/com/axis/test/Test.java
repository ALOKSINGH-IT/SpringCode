package com.axis.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.axis.beans.Cache;

public class Test {
 
	public static void main(String[] args) {
	
		
		ApplicationContext context = new  ClassPathXmlApplicationContext("com/axis/config/Beans.xml");
		 Cache c1=context.getBean("c", Cache.class);
		  System.out.println(c1);

	}

}
