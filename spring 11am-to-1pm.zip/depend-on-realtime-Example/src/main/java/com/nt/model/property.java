package com.nt.model;

public class property {
	private String tcs

}
