package com.nt.model;

public class LoanCalculator {

}
