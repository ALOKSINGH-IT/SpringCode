package com.nt.model;

public class Cache {

}
