package com.nt.model;

public class CacheManager {

}
