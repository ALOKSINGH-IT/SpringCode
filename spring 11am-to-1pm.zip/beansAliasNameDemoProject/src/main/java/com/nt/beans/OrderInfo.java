package com.nt.beans;

public class OrderInfo {
	private String orderId;
	private String itemNames;
	private Double price;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getItemNames() {
		return itemNames;
	}
	public void setItemNames(String itemNames) {
		this.itemNames = itemNames;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "OrderInfo [orderId=" + orderId + ", itemNames=" + itemNames + ", price=" + price + "]";
	}
	

}
