package com.nt.beans;

public class Amzon {
	 private ICourier bludartcourier;
	 private ICourier dtdcourier;
	 
	 
	 public void setBludartcourier(ICourier bludartcourier) {
		this.bludartcourier = bludartcourier;
	}


	public void setDtdcourier(ICourier dtdcourier) {
		this.dtdcourier = dtdcourier;
	}
	public void processOrder(OrderInfo order,SippingAddress add) 
	{
		 //if(long ZipCode = sippingaddress.getZip();
		 
		if(add.getZipCode()>=50000)
			{
				bludartcourier.dilivery();
			}else
			{
				dtdcourier.dilivery();
			}
	
	 }
	 
}
