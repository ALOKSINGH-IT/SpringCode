package com.nt.beans;

public class DtdcCourier  implements ICourier {

	public void dilivery() {

		System.out.println("deliverd through DTDC!! ");
	}
	
	

}
