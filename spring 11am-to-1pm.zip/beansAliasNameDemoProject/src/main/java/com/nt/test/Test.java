package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.beans.Amzon;
import com.nt.beans.OrderInfo;
import com.nt.beans.SippingAddress;

public class Test {
	
	public static void main(String[] args) {
		
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com/nt/cfg/Beans.xml");
		
		OrderInfo oi=ctx.getBean("order", OrderInfo.class);
		 SippingAddress sip=ctx.getBean("shipadd",SippingAddress.class);
		Amzon am=ctx.getBean("amaz",Amzon.class);
		
		am.processOrder(oi, sip);
		
	
	}

}
