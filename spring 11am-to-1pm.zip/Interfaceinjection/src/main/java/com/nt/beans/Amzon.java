package com.nt.beans;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Amzon  implements ApplicationContextAware{
	
	 private ApplicationContext applicationContext=null;
	public void processOrder() 
	{
		 //if(long ZipCode = sippingaddress.getZip();
	
		SippingAddress add=	applicationContext.getBean("shipadd",SippingAddress.class);
		if(add.getZipCode()>=50000)
			{
			
	
			BludartCourier blue	=applicationContext.getBean("bludart",BludartCourier.class);
			OrderInfo oinfo=	applicationContext.getBean("order",OrderInfo.class);
			System.out.println(oinfo);
			
			System.out.println(add);
			blue.dilivery();	
			}else
			{
				OrderInfo oinfo=	applicationContext.getBean("order",OrderInfo.class);
				System.out.println(oinfo);
				DtdcCourier dtdc=applicationContext.getBean("dtdc",DtdcCourier.class);
				System.out.println(add);
				dtdc.dilivery();
			}
	
	 }


	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

	
		this.applicationContext=applicationContext;
	}
	 
}
