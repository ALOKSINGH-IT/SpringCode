package com.nt.beans;

public interface ICourier {
	public void dilivery();

}





















