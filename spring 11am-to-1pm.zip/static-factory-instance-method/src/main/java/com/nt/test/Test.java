package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.DeptService;

public class Test {
	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com/nt/cfg/Beans.xml");
		DeptService ds=	ctx.getBean("deptService", DeptService.class);
		ds.save(101, "alok");
		
	}

}
