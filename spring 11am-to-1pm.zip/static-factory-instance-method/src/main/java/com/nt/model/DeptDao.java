package com.nt.model;

public class DeptDao {
	
	public boolean insert(int id, String name) {
		System.out.println("Record inserted..");
		return true;
	}
}
