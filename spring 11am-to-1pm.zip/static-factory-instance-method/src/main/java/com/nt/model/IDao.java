package com.nt.model;

public interface IDao {
	public Object getInstance();

}
