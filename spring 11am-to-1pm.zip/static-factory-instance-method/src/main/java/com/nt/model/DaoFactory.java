package com.nt.model;

public class DaoFactory  implements IDao{

	public Object getInstance() {
		System.out.println("Preparing DataSource");
		System.out.println("preparing JDBCTemplate");
		return new DeptDao();
		
		
	}

}
