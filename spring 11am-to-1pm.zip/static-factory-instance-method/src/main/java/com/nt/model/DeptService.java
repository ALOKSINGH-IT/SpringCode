package com.nt.model;

public class DeptService {
	private DeptDao  deptdao;
	
	public void save(int id,String name) {
		deptdao.insert(id, name);
		}

	public void setDeptdao(DeptDao deptdao) {
		this.deptdao = deptdao;
	}
	

}
