package singal.com.alok;

public class Custom {
private Custom() {
		
	}
	public static instance;
	
	
	
	public static  Custom create() {
		
		Custom ct= new Custom();
		
		
		return Custom;
		
	}
	

}
