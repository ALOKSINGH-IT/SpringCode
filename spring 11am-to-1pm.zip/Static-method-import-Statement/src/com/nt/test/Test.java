package com.nt.test;

 import static  com.nt.alok.Employee.*;
 
public class Test {
	
		public static void main(String[] args) {
			System.out.println(a);
			m1();
			
			
		}
	

}
