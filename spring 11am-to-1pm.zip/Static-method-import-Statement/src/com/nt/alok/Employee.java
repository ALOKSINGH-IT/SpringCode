package com.nt.alok;

public class Employee {
	public static int a=30;
	
	public  static void m1() {
		System.out.println("hello");
	}

}
