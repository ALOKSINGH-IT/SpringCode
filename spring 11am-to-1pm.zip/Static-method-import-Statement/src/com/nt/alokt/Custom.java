package com.nt.alokt;

public class Custom {
	private Custom() {
		
	}
	public  custom createme() {
		
		return custom;
		
	}

}
