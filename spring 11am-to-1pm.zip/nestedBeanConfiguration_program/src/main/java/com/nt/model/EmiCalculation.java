package com.nt.model;

public class EmiCalculation {
	public float cumpute(long principai,float rateOfInterest,int year) {
		return 343.43f;
		
	}

}
