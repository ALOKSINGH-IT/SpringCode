package com.nt.model;

public class CustomerLoanAprove {
	private EmiCalculation emicalculation;
	
	public void aprove(double groseSalary,double principalAmount,int year) {
		float emi=emi Calculator Compute(principalAmount,5457f,year)
	}

}
