package com.nt.model;

import java.util.Calendar;
import java.util.Date;

public class DateUtilDemo {
	private Calendar calendar;

	public void setCalender(Calendar calendar) {
		this.calendar = calendar;
	}
	
	public void getDate() {
		Date d = calendar.getTime();
		System.out.println(d);
		}

	@Override
	public String toString() {
		return "DateUtilDemo [calendar=" + calendar + "]";
	}
	

}
