package com.nt.model;

public class Student {
	private int sno;
	public Student(int sno, String sname, String clgname, String address) {
		super();
		this.sno = sno;
		Sname = sname;
		Clgname = clgname;
		Address = address;
	}

	private String Sname;
	private String Clgname;
	private String Address;
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [sno=" + sno + ", Sname=" + Sname + ", Clgname=" + Clgname + ", Address=" + Address + "]";
	}
	

}
