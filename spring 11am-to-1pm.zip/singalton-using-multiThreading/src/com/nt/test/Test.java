package com.nt.test;

import com.nt.model.Company;

public class Test {
	public static void main(String[] args) {
		
		
		Company com1= new Company();
		
		
		Company com2= new Company();
		
		com1.start();
		
		
	}

}
