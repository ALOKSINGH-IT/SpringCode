package com.nt.model;

public class Company extends Thread {
	public void run() {
		
	
	
	Employe emp=Employe.getinstance();

	Employe emp1=Employe.getinstance();
	
	System.out.println(emp.hashCode());
	
	System.out.println(emp1.hashCode());
	}
	
	
}
