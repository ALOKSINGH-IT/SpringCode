package com.nt.model;

public class Employe {
	
	public static Employe instance;
	private Employe() {
		
	}

public static Employe getinstance() {
		if(instance==null)
			instance = new Employe();
		return instance;
	}
	

}
