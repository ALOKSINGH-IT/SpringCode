package com.nt.model;

public class Company {
	private String cname;
	private String address;
	
	public Company() {
		super();
	}

	public Company(String cname, String address) {
		super();
		this.cname = cname;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Company [cname=" + cname + ", address=" + address + "]";
	}
	
	

}
