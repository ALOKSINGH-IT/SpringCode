package com.nt.model;

public class Employee {
	private int eid;
	private String ename;
	private Company com;
	public void setCom(Company com) {
		this.com = com;
	}
	public void setEid(int eid) {
		this.eid = eid;
}
	public void setEname(String ename) {
		this.ename = ename;
}
	
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", com=" + com + "]";
	}
	

}
