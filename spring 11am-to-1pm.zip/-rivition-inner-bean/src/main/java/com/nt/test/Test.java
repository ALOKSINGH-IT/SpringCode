package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.nt.model.HpPrinter;
import com.nt.model.Printer;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/nt/cfg/beans.xml");
	Printer pnt = context.getBean("p1",Printer.class);
	System.out.println(pnt);
	}

}
