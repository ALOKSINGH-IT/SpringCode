package com.nt.model;

public class Printer {
	private int pid;
	private String pcolor;
	private HpPrinter hprinter;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPcolor() {
		return pcolor;
	}
	public void setPcolor(String pcolor) {
		this.pcolor = pcolor;
	}
	public HpPrinter getHprinter() {
		return hprinter;
	}
	public void setHprinter(HpPrinter hprinter) {
		this.hprinter = hprinter;
	}
	@Override
	public String toString() {
		return "Printer [pid=" + pid + ", pcolor=" + pcolor + ", hprinter=" + hprinter + "]";
	}
	

}
