package com.nt.model;

public class HpPrinter {
	private int hid;
	private String hname;
	
	public int getHid() {
		return hid;
	}

	public void setHid(int hid) {
		this.hid = hid;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}

	@Override
	public String toString() {
		return "HpPrinter [hid=" + hid + ", hname=" + hname + "]";
	}
	

}
