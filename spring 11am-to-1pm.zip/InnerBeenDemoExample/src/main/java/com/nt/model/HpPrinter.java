package com.nt.model;

public class HpPrinter  implements IPrinter{

	public HpPrinter() {
		System.out.println("HpPrinter");
	}
	public void printReceipt(double amt) {
		// TODO Auto-generated method stub
		
		System.out.println("hello hpPrineter" + amt);
		
	}
	

}
