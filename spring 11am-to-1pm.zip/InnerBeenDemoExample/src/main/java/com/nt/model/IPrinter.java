package com.nt.model;

public interface IPrinter {

	 public void printReceipt(double amt);

}
