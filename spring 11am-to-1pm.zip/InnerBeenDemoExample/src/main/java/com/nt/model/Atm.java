package com.nt.model;

public class Atm {
	 private IPrinter printer;
	 
	public void checkBal(int pin) {
		
		printer.printReceipt(4500.78);
	}

	public IPrinter getPrinter() {
		return printer;
	}

	public void setPrinter(IPrinter printer) {
		this.printer = printer;
	}

	
}
