package com.nt.model;

public class SonyPrinter implements IPrinter{
	
public SonyPrinter() {
	System.out.println("sonyPrinter");
}
	public void printReceipt(double amt) {
		System.out.println("Printing.....");
		System.out.println("Balance : " + amt);
	}
	
		// TODO Auto-generated method stub
		
	}


