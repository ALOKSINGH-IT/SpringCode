package com.nt.model;

public class Censor {
	private int sno;
	private String Sname;
	
	public void setSno(int sno) {
		this.sno = sno;
		System.out.println("censor");
	}

	public void setSname(String sname) {
		Sname = sname;
	}
	@Override
	public String toString() {
		return "Censor [sno=" + sno + ", Sname=" + Sname + "]";
	}
	

}
