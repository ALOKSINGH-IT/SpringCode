package com.nt.model;

public class Chip {
	private int ChipNo;
	private String chiptype;
	
	public void setChipNo(int chipNo) {
		ChipNo = chipNo;
	}
	public void setChiptype(String chiptype) {
		this.chiptype = chiptype;
	}
	@Override
	public String toString() {
		return "Chip [ChipNo=" + ChipNo + ", chiptype=" + chiptype + "]";
	}
	

}
