package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.nt.model.Censor;
import com.nt.model.Chip;

public class Test {
	public static void main(String[] args) {
		Resource res=new ClassPathResource("com/nt/cfg/beans.xml");
		BeanFactory factory = new XmlBeanFactory(res);
	Censor c1 = factory.getBean("censor1", Censor.class);
	Censor c2 = factory.getBean("censor1", Censor.class);
	Censor c3 = factory.getBean("censor1", Censor.class);
	Chip c5 = factory.getBean("chip1",Chip.class);
	System.out.println("chipfgf");
	System.out.println("c1");
	
		
	}

}
