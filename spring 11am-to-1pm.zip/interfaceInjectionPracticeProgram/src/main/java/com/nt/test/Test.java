package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.nt.beans.SippingAddress;
import com.nt.model.Amzon;
import com.nt.model.SippingAddress;

public class Test {
	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com/nt/cfg/Beans.xml");
		
		 SippingAddress sip=ctx.getBean("sippingaddress",SippingAddress.class);
		 
		Amzon am = ctx.getBean("amaz", Amzon.class);
		//System.out.println(am);
		am.processOrder();
		
	}

}
