package com.nt.model;

public class BludartCourier implements ICourier {

	public void dilivery() {
		// TODO Auto-generated method stub
		System.out.println("deliverd through Bluedart");
	}
	

}
