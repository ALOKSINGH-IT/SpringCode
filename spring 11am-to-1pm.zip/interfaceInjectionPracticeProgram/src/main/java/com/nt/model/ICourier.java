package com.nt.model;

public interface ICourier {
	public void dilivery();

}





















