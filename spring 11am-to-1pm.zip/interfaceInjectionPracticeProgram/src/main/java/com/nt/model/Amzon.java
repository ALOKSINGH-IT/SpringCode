package com.nt.model;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Amzon  implements ApplicationContextAware{
	
	private ApplicationContext applicationContext = null;
	public void processOrder() 
	{
		 Amzon  add = applicationContext.getBean("amaz", Amzon.class);
		 SippingAddress sad= applicationContext.getBean("sippingaddress", SippingAddress.class);
		 OrderInfo oinfo = applicationContext.getBean("orderInfo",OrderInfo.class);
		 
		 
		 
	}
	

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub
		
	}
	
	 
}
