package com.nt.model;
public class SippingAddress {
	
	private int aid;
	private String streetaddress;
	private String city;
	private String state;
	private long ZipCode;
	
	public long getZipCode() {
		return ZipCode;
	}
	
	public void setZipCode(long zipCode) {
		ZipCode = zipCode;
	}
	
	public int getAid() {
		return aid;
	}
	
	public void setAid(int aid) {
		this.aid = aid;
	}
	
	public String getStreetaddress() {
		return streetaddress;
	}
	
	public void setStreetaddress(String streetaddress) {
		this.streetaddress = streetaddress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "SippingAddress [aid=" + aid + ", streetaddress=" + streetaddress + ", city=" + city + ", state=" + state
				+ ", ZipCode=" + ZipCode + "]";
	}
	

}
